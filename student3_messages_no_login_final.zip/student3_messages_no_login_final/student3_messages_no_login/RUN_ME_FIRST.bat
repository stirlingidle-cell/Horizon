@echo off
echo ================================
echo SKY Messages Django Project
echo Adjusted Student 3 Messages App
echo ================================
echo.
echo Installing dependencies...
python -m pip install -r requirements.txt
echo.
echo Applying migrations...
python manage.py migrate
echo.
echo Creating demo users from inside messages_app...
python messages_app/create_demo_users.py
echo.
echo Starting server on port 8080...
echo Open this in Chrome: http://127.0.0.1:8080/
python manage.py runserver 8080
pause
