SKY Messages Project - Student 3
Adjusted version: demo user script moved inside messages_app.

IMPORTANT:
Open the folder that contains manage.py before running commands.
The folder should show:
- manage.py
- messages_app
- sky_project
- requirements.txt

HOW TO RUN:

1. Install dependencies:
   python -m pip install -r requirements.txt

2. Apply migrations:
   python manage.py migrate

3. Create demo users:
   python messages_app/create_demo_users.py

4. Start the server:
   python manage.py runserver

5. Open:
   http://127.0.0.1:8000/

If port 8000 is busy, run:
   python manage.py runserver 8080

Then open:
   http://127.0.0.1:8080/

LOGIN DETAILS:

Normal app login:
   Username: ceyda
   Password: password123

Second test user:
   Username: manager
   Password: password123

Django admin login:
   Username: admin
   Password: admin123

NOTE:
The demo user creation script is now inside:
   messages_app/create_demo_users.py

The following files are intentionally outside messages_app because this is required by Django:
- manage.py
- sky_project/settings.py
- sky_project/urls.py
- db.sqlite3
- requirements.txt
