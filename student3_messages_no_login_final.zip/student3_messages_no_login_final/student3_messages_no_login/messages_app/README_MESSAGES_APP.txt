Student 3 Messages App

This folder contains the main code for the messages functionality:
- models.py: Message database model
- views.py: inbox, sent, drafts, new message, login/register/dashboard logic
- urls.py: message page routes
- admin.py: registers Message in Django admin
- create_demo_users.py: creates demo login users and a sample message
- templates/messages_app/: HTML pages for this app

Important:
Django still requires manage.py and sky_project/settings.py outside this app folder.
Do not move those into messages_app.
