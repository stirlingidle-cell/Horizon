from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Message


def dashboard(request):
    if request.user.is_authenticated:
        inbox_count = Message.objects.filter(receiver=request.user, is_draft=False).count()
        sent_count = Message.objects.filter(sender=request.user, is_draft=False).count()
        draft_count = Message.objects.filter(sender=request.user, is_draft=True).count()
    else:
        inbox_count = 0
        sent_count = 0
        draft_count = 0

    return render(request, 'messages_app/dashboard.html', {
        'inbox_count': inbox_count,
        'sent_count': sent_count,
        'draft_count': draft_count,
    })


@login_required
def inbox(request):
    msgs = Message.objects.filter(receiver=request.user, is_draft=False)
    return render(request, 'messages_app/inbox.html', {'messages_list': msgs})


@login_required
def sent(request):
    msgs = Message.objects.filter(sender=request.user, is_draft=False)
    return render(request, 'messages_app/sent.html', {'messages_list': msgs})


@login_required
def drafts(request):
    msgs = Message.objects.filter(sender=request.user, is_draft=True)
    return render(request, 'messages_app/drafts.html', {'messages_list': msgs})


@login_required
def new_message(request):
    users = User.objects.exclude(id=request.user.id)

    if request.method == 'POST':
        receiver_id = request.POST.get('receiver')
        subject = request.POST.get('subject')
        content = request.POST.get('content')
        is_draft = 'save_draft' in request.POST

        receiver = get_object_or_404(User, id=receiver_id)

        Message.objects.create(
            sender=request.user,
            receiver=receiver,
            subject=subject,
            content=content,
            is_draft=is_draft
        )

        if is_draft:
            return redirect('drafts')

        return redirect('sent')

    return render(request, 'messages_app/new_message.html', {'users': users})


@login_required
def view_message(request, message_id):
    msg = get_object_or_404(Message, id=message_id)

    if msg.receiver != request.user and msg.sender != request.user:
        return redirect('inbox')

    return render(request, 'messages_app/view_message.html', {'message_obj': msg})


@login_required
def delete_message(request, message_id):
    msg = get_object_or_404(Message, id=message_id)

    if msg.receiver == request.user or msg.sender == request.user:
        msg.delete()

    return redirect('inbox')