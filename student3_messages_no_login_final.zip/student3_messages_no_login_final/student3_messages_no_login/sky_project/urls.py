from django.contrib import admin
from django.urls import path, include
from messages_app import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('admin/', admin.site.urls),
    path('messages/', include('messages_app.urls')),
]
